#include<iostream>
#include<fstream>
#include<string>

using namespace std;

int main(int argc, char * argv[])
{
	string name(argv[1]);
	name = name.substr(0, name.find_last_of("."));

	ifstream infile(argv[1],ios::in);
	ofstream outfile((name+"_GC1_GC3.txt").c_str(),ios::out);
	string s,line;
	float N,n,m,P;
	int i,t,temp;
	temp=0;
	P=0;
	t=1;
	float pGC[100000];
	while(getline(infile,line))
	{
		if(line[0]=='>')
		{
			if(temp)
			{
				N=n=m=0.0;
				while(s[n])
				{
					if(s[n]=='G'&&s[n+2]=='C')
					{
						m++;
					    n=n+3;
					    N++;
					}
					else if(s[n]=='G'&&s[n+2]=='G')
					{
						m++;
					    n=n+3;
					    N++;
					}
					else if(s[n]=='C'&&s[n+2]=='G')
					{
						m++;
					    n=n+3;
					    N++;
					}
					else if(s[n]=='C'&&s[n+2]=='C')
					{
						m++;
					    n=n+3;
					    N++;
					}
				    else
					{
					    n=n+3;
					    N++;
					}
				}
				N=N-1;
			    pGC[t]=m/N;
			    outfile<<pGC[t]<<endl;
			    t++;
			    s="";
				temp=0;
			}
		}
		else
		{
			s+=line;
			temp=1;
		}
	}
	if(temp)
	{
		N=n=m=0.0;
		while(s[n])
		{
			if(s[n]=='G'&&s[n+2]=='C')
			{
				m++;
			    n=n+3;
			    N++;
			}
			else if(s[n]=='G'&&s[n+2]=='G')
			{
				m++;
			    n=n+3;
			    N++;
			}
			else if(s[n]=='C'&&s[n+2]=='G')
			{
				m++;
			    n=n+3;
			    N++;
			}
			else if(s[n]=='C'&&s[n+2]=='C')
			{
				m++;
			    n=n+3;
			    N++;
			}
		    else
			{
			    n=n+3;
			    N++;
			}
		}
		N=N-1;
	    pGC[t]=m/N;
	    outfile<<pGC[t]<<endl;
	    t++;
	}
	for(i=1;i<t;i++)
		P+=pGC[i]/t;
	infile.close();
	outfile.close();
	return 0;
}
