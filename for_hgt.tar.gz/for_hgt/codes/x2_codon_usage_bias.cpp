#include<iostream>
#include<fstream>
#include<string>
#include<math.h>

using namespace std;
float Bp[100000][20],Bfcg[100000][20][6],F[100000][20],B[100000][20];

int main(int argc, char * argv[])
{
	string name(argv[1]);
	name = name.substr(0, name.find_last_of("."));

	ifstream infile(argv[1],ios::in);
	ofstream outfile((name+"_x2_codon_usage_bias.txt").c_str(),ios::out);
	string s,line;
	float N,n,M,BgG,m[20],c[20][6],T[20][6],P[20],Fcg[20][6],FcG[20][6];	
	int i,j,t,W;
	int temp=0;
	W=N=0;
    for(i=0;i<20;i++)
		m[i]=0;
	for(i=0;i<20;i++)
		for(j=0;j<6;j++)
			T[i][j]=0;
	while(getline(infile,line))
	{ 
		if(line[0]=='>')
		{
			if(temp) 
			{
				M=n=0;
				for(i=0;i<20;i++)
					for(j=0;j<6;j++)
						c[i][j]=0;
				W++;
				while(s[n])
				{
					if(s[n]=='T')
					{
						n++;
						if(s[n]=='T')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[0][0]++;m[0]++; }
							else if(s[n]=='C') { n++;M++;c[0][1]++;m[0]++; }
							else if(s[n]=='A') { n++;M++;c[1][0]++;m[1]++; }
							else if(s[n]=='G') { n++;M++;c[1][1]++;m[1]++; }
						}
						else if(s[n]=='C')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[2][0]++;m[2]++; }
							else if(s[n]=='C') { n++;M++;c[2][1]++;m[2]++; }
							else if(s[n]=='A') { n++;M++;c[2][2]++;m[2]++; }
							else if(s[n]=='G') { n++;M++;c[2][3]++;m[2]++; }
						}
						else if(s[n]=='A')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[3][0]++;m[3]++; }
							else if(s[n]=='C') { n++;M++;c[3][1]++;m[3]++; }
							else if(s[n]=='A'||s[n]=='G') { n++;M++; }
						}
						else if(s[n]=='G')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[4][0]++;m[4]++; }
							else if(s[n]=='C') { n++;M++;c[4][1]++;m[4]++; }
							else if(s[n]=='A') { n++;M++; }
							else if(s[n]=='G') { n++;M++;c[5][0]++;m[5]++; }
						}
					}
					else if(s[n]=='C')
					{
						n++;
						if(s[n]=='T')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[1][2]++;m[1]++; }
							else if(s[n]=='C') { n++;M++;c[1][3]++;m[1]++; }
							else if(s[n]=='A') { n++;M++;c[1][4]++;m[1]++; }
							else if(s[n]=='G') { n++;M++;c[1][5]++;m[1]++; }
						}
						else if(s[n]=='C')
						{
							n++;
                            if(s[n]=='T') { n++;M++;c[6][0]++;m[6]++; }
							else if(s[n]=='C') { n++;M++;c[6][1]++;m[6]++; }
							else if(s[n]=='A') { n++;M++;c[6][2]++;m[6]++; }
							else if(s[n]=='G') { n++;M++;c[6][3]++;m[6]++; }
						}
						else if(s[n]=='A')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[7][0]++;m[7]++; }
							else if(s[n]=='C') { n++;M++;c[7][1]++;m[7]++; }
							else if(s[n]=='A') { n++;M++;c[8][0]++;m[8]++; }
							else if(s[n]=='G') { n++;M++;c[8][1]++;m[8]++; }
						}
						else if(s[n]=='G')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[9][0]++;m[9]++; }
							else if(s[n]=='C') { n++;M++;c[9][1]++;m[9]++; }
							else if(s[n]=='A') { n++;M++;c[9][2]++;m[9]++; }
							else if(s[n]=='G') { n++;M++;c[9][3]++;m[9]++; }
						}
					}
					else if(s[n]=='A')
					{
						n++;
						if(s[n]=='T')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[10][0]++;m[10]++; }
							else if(s[n]=='C') { n++;M++;c[10][1]++;m[10]++; }
							else if(s[n]=='A') { n++;M++;c[10][2]++;m[10]++; }
							else if(s[n]=='G') { n++;M++;c[11][0]++;m[11]++; }
						}
						else if(s[n]=='C')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[12][0]++;m[12]++; }
							else if(s[n]=='C') { n++;M++;c[12][1]++;m[12]++; }
							else if(s[n]=='A') { n++;M++;c[12][2]++;m[12]++; }
							else if(s[n]=='G') { n++;M++;c[12][3]++;m[12]++; }
						}
						else if(s[n]=='A')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[13][0]++;m[13]++; }
							else if(s[n]=='C') { n++;M++;c[13][1]++;m[13]++; }
							else if(s[n]=='A') { n++;M++;c[14][0]++;m[14]++; }
							else if(s[n]=='G') { n++;M++;c[15][0]++;m[14]++; }
						}
						else if(s[n]=='G')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[2][4]++;m[2]++; }
							else if(s[n]=='C') { n++;M++;c[2][5]++;m[2]++; }
							else if(s[n]=='A') { n++;M++;c[9][4]++;m[9]++; }
							else if(s[n]=='G') { n++;M++;c[9][5]++;m[9]++; }
						}
					}
					else if(s[n]=='G')
					{
						n++;
						if(s[n]=='T')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[15][0]++;m[15]++; }
							else if(s[n]=='C') { n++;M++;c[15][1]++;m[15]++; }
							else if(s[n]=='A') { n++;M++;c[15][2]++;m[15]++; }
							else if(s[n]=='G') { n++;M++;c[15][3]++;m[15]++; }
						}
						else if(s[n]=='C')
						{
							n++;
                            if(s[n]=='T') { n++;M++;c[16][0]++;m[16]++; }
							else if(s[n]=='C') { n++;M++;c[16][1]++;m[16]++; }
							else if(s[n]=='A') { n++;M++;c[16][2]++;m[16]++; }
							else if(s[n]=='G') { n++;M++;c[16][3]++;m[16]++; }
						}
						else if(s[n]=='A')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[17][0]++;m[17]++; }
							else if(s[n]=='C') { n++;M++;c[17][1]++;m[17]++; }
							else if(s[n]=='A') { n++;M++;c[18][0]++;m[18]++; }
							else if(s[n]=='G') { n++;M++;c[18][1]++;m[18]++; }
						}
						else if(s[n]=='G')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[19][0]++;m[19]++; }
							else if(s[n]=='C') { n++;M++;c[19][1]++;m[19]++; }
							else if(s[n]=='A') { n++;M++;c[19][2]++;m[19]++; }
							else if(s[n]=='G') { n++;M++;c[19][3]++;m[19]++; }
						}
					}
				}
				for(i=0;i<20;i++)
					for(j=0;j<6;j++)
						T[i][j]+=c[i][j];
				N+=M;
			//	cout<<n<<endl;//
			//	cout<<M<<endl;//
				// cout<<W<<endl;
				for(i=0;i<20;i++)
				{
					P[i]=m[i]/M;
					Bp[W-1][i]=P[i];
				}
				for(i=0;i<20;i++)
					for(j=0;j<6;j++)
					{
					    Fcg[i][j]=c[i][j]/M;
				    	Bfcg[W-1][i][j]=Fcg[i][j];
					}
				s="";
				temp=0;
			}
		}
		else
		{
			s+=line;
			temp=1;
		}
	}
	if(temp) 
	{
		M=n=0;
		for(i=0;i<20;i++)
			for(j=0;j<6;j++)
				c[i][j]=0;
		W++;
		while(s[n])
		{
			if(s[n]=='T')
			{
				n++;
				if(s[n]=='T')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[0][0]++;m[0]++; }
					else if(s[n]=='C') { n++;M++;c[0][1]++;m[0]++; }
					else if(s[n]=='A') { n++;M++;c[1][0]++;m[1]++; }
					else if(s[n]=='G') { n++;M++;c[1][1]++;m[1]++; } 
				}
				else if(s[n]=='C')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[2][0]++;m[2]++; }
					else if(s[n]=='C') { n++;M++;c[2][1]++;m[2]++; }
					else if(s[n]=='A') { n++;M++;c[2][2]++;m[2]++; }
					else if(s[n]=='G') { n++;M++;c[2][3]++;m[2]++; }
				}
				else if(s[n]=='A')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[3][0]++;m[3]++; }
					else if(s[n]=='C') { n++;M++;c[3][1]++;m[3]++; }
					else if(s[n]=='A'||s[n]=='G') { n++;M++; }
				}
				else if(s[n]=='G')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[4][0]++;m[4]++; }
					else if(s[n]=='C') { n++;M++;c[4][1]++;m[4]++; }
					else if(s[n]=='A') { n++;M++; }
					else if(s[n]=='G') { n++;M++;c[5][0]++;m[5]++; }
				}
			}
			else if(s[n]=='C')
			{
				n++;
				if(s[n]=='T')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[1][2]++;m[1]++; }
					else if(s[n]=='C') { n++;M++;c[1][3]++;m[1]++; }
					else if(s[n]=='A') { n++;M++;c[1][4]++;m[1]++; }
					else if(s[n]=='G') { n++;M++;c[1][5]++;m[1]++; }
				}
				else if(s[n]=='C')
				{
					n++;
                    if(s[n]=='T') { n++;M++;c[6][0]++;m[6]++; }
					else if(s[n]=='C') { n++;M++;c[6][1]++;m[6]++; }
					else if(s[n]=='A') { n++;M++;c[6][2]++;m[6]++; }
					else if(s[n]=='G') { n++;M++;c[6][3]++;m[6]++; }
				}
				else if(s[n]=='A')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[7][0]++;m[7]++; }
					else if(s[n]=='C') { n++;M++;c[7][1]++;m[7]++; }
					else if(s[n]=='A') { n++;M++;c[8][0]++;m[8]++; }
					else if(s[n]=='G') { n++;M++;c[8][1]++;m[8]++; }
				}
				else if(s[n]=='G')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[9][0]++;m[9]++; }
					else if(s[n]=='C') { n++;M++;c[9][1]++;m[9]++; }
					else if(s[n]=='A') { n++;M++;c[9][2]++;m[9]++; }
					else if(s[n]=='G') { n++;M++;c[9][3]++;m[9]++; }
				}
			}
			else if(s[n]=='A')
			{
				n++;
				if(s[n]=='T')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[10][0]++;m[10]++; }
					else if(s[n]=='C') { n++;M++;c[10][1]++;m[10]++; }
					else if(s[n]=='A') { n++;M++;c[10][2]++;m[10]++; }
					else if(s[n]=='G') { n++;M++;c[11][0]++;m[11]++; }
				}
				else if(s[n]=='C')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[12][0]++;m[12]++; }
					else if(s[n]=='C') { n++;M++;c[12][1]++;m[12]++; }
					else if(s[n]=='A') { n++;M++;c[12][2]++;m[12]++; }
					else if(s[n]=='G') { n++;M++;c[12][3]++;m[12]++; }
				}
				else if(s[n]=='A')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[13][0]++;m[13]++; }
					else if(s[n]=='C') { n++;M++;c[13][1]++;m[13]++; }
					else if(s[n]=='A') { n++;M++;c[14][0]++;m[14]++; }
					else if(s[n]=='G') { n++;M++;c[15][0]++;m[14]++; }
				}
				else if(s[n]=='G')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[2][4]++;m[2]++; }
					else if(s[n]=='C') { n++;M++;c[2][5]++;m[2]++; }
					else if(s[n]=='A') { n++;M++;c[9][4]++;m[9]++; }
					else if(s[n]=='G') { n++;M++;c[9][5]++;m[9]++; }
				}
			}
			else if(s[n]=='G')
			{
				n++;
				if(s[n]=='T')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[15][0]++;m[15]++; }
					else if(s[n]=='C') { n++;M++;c[15][1]++;m[15]++; }
					else if(s[n]=='A') { n++;M++;c[15][2]++;m[15]++; }
					else if(s[n]=='G') { n++;M++;c[15][3]++;m[15]++; }
				}
				else if(s[n]=='C')
				{
					n++;
                    if(s[n]=='T') { n++;M++;c[16][0]++;m[16]++; }
					else if(s[n]=='C') { n++;M++;c[16][1]++;m[16]++; }
					else if(s[n]=='A') { n++;M++;c[16][2]++;m[16]++; }
					else if(s[n]=='G') { n++;M++;c[16][3]++;m[16]++; }
				}
				else if(s[n]=='A')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[17][0]++;m[17]++; }
					else if(s[n]=='C') { n++;M++;c[17][1]++;m[17]++; }
					else if(s[n]=='A') { n++;M++;c[18][0]++;m[18]++; }
					else if(s[n]=='G') { n++;M++;c[18][1]++;m[18]++; }
				}
				else if(s[n]=='G')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[19][0]++;m[19]++; }
					else if(s[n]=='C') { n++;M++;c[19][1]++;m[19]++; }
					else if(s[n]=='A') { n++;M++;c[19][2]++;m[19]++; }
					else if(s[n]=='G') { n++;M++;c[19][3]++;m[19]++; }
				}
			}
		}
		for(i=0;i<20;i++)
			for(j=0;j<6;j++)
				T[i][j]+=c[i][j];
		N+=M;
	//	cout<<n<<endl;//
	//	cout<<M<<endl;//
		// cout<<W<<endl;
		for(i=0;i<20;i++)
		{
			P[i]=m[i]/M;
			Bp[W-1][i]=P[i];
		}
		for(i=0;i<20;i++)
			for(j=0;j<6;j++)
			{
			    Fcg[i][j]=c[i][j]/M;
		    	Bfcg[W-1][i][j]=Fcg[i][j];
			}
	}
	infile.close();
//	cout<<W<<endl;// 
	for(i=0;i<20;i++)
		for(j=0;j<6;j++)
			FcG[i][j]=T[i][j]/N;
	for(t=0;t<W;t++)//
		for(i=0;i<20;i++)
			F[t][i]=0.0;
	for(t=0;t<W;t++)
		for(i=0;i<20;i++)
			for(j=0;j<6;j++)
				F[t][i]+=fabs(Bfcg[t][i][j]-FcG[i][j]);
    for(t=0;t<W;t++)
		for(i=0;i<20;i++)
			B[t][i]=Bp[t][i]*F[t][i];
	float sum_BgG=0.0;
	for(t=0;t<W;t++)
	{
		BgG=0;
		for(i=0;i<20;i++)
			BgG+=B[t][i];
		sum_BgG+=BgG;
	}
	float E=sum_BgG/W;
	for(t=0;t<W;t++)
	{
		BgG=0;
		for(i=0;i<20;i++)
			BgG+=B[t][i];
		outfile<<-pow(BgG-E, 2)/BgG<<endl;
	}
	outfile.close();
	return 0;
}
