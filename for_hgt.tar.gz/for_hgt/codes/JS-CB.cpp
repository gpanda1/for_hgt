#include<iostream>
#include<fstream>
#include<string>
#include<math.h>

using namespace std;

float JS[10000][10000],C[10000][20][6];
double gamm2(double a,double x,double e1,double e0);
double gammln(double x);

#define NMAX 100

double gammln(double x)
{
  int i;
  double t,s;
  static double c[6] = {76.18009172947148,
            -86.50532032941677,24.01409824083091,
            -1.231739572450155,0.1208650973866179e-2,
            -0.5395239384953e-5}; 
  if(x<0)
    return(0.0);
  s = 1.000000000190015;
  for(i=0; i<6; i++)     
    s = s+c[i]/(x+i);
  t = x+4.5;              
  t = t-(x-0.5)*log(t);
  t = log(2.5066282746310005*s)-t;  
  return(t);
}

double gamm2(double a,double x,double e1,double e0)
{
  int n;
  double t,del,gln;
  double an,bn,c,d;      
  if((x<0.0)||(a<=0))
    return(0.0);
  if(x<e0)
    return(0.0);
  gln = gammln(a);
  if(x<(a+1.0))    
  {
    del = 1.0/a;    
    t = 1.0/a;
    for(n=1; n<NMAX; n++)
    {
      del = del*x/(a+n);
      t = t+del;
      if(fabs(del)<fabs(t)*e1)  
      {
        t = t*exp(-x+a*log(x)-gln);
        return(t);
      }
    }
    return(0.0);
  }
  else          
  {
    bn = x+1.0-a;
    c = 1.0/e0;
    d = 1.0/bn;
    t = d;
    for(n=1; n<NMAX; n++)
    {
      an = n*(a-n);
      bn = bn+2.0;
      d = an*d+bn;
      c = bn+an/c;
      if(fabs(d) < e0)
        d = e0;
      if(fabs(c) < e0)
        c = e0;
      d = 1.0/d;
      del = d*c;
      t = t*del;
      if(fabs(del-1.0)<e1)
      {
        t=exp(-x+a*log(x)-gln)*t;
        t = 1.0-t;
        return(t);
      }
    }
    return(0.0);
  }
}


int main(int argc, char * argv[])
{
	string name(argv[1]);
	name = name.substr(0, name.find_last_of("."));

	ifstream infile(argv[1],ios::in);
	ofstream outfile((name+"_JS_CB.txt").c_str(),ios::out);
	string s,line;
	float c[20][6],m[20],Sf[20],SK[10000],F[10000][20],N[10000];
	float Call[20][6],Fall[20],Nall,Sn[20],Sn1;
	float S1,JS,SF[20],S;
	int i,j,k,temp,n,M,W;
	float Pr,NUM;
	double e1=1.0e-7,e0=1.0e-30; 
	double x,y,z;
	W=temp=0;
	Nall=0.0;
	for(i=0;i<20;i++)
		for(j=0;j<6;j++)
			Call[i][j]=0.0;
	for(i=0;i<20;i++)
		Fall[i]=0.0;
	while(getline(infile,line))
	{ 
		if(line[0]=='>')
		{
			if(temp)
			{
				M=n=0;
				S1=0;
				W++;
				for(i=0;i<20;i++)
					m[i]=Sf[i]=0;
				for(i=0;i<20;i++)
					for(j=0;j<6;j++)
						c[i][j]=0;
				while(s[n])
				{
					if(s[n]=='T')
					{
						n++;
						if(s[n]=='T')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[0][0]++;m[0]++;}
							else if(s[n]=='C') { n++;M++;c[0][1]++;m[0]++;}
							else if(s[n]=='A') { n++;M++;c[1][0]++;m[1]++;}
							else if(s[n]=='G') { n++;M++;c[1][1]++;m[1]++;} 
						}
						else if(s[n]=='C')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[2][0]++;m[2]++;}
							else if(s[n]=='C') { n++;M++;c[2][1]++;m[2]++;}
							else if(s[n]=='A') { n++;M++;c[2][2]++;m[2]++;}
							else if(s[n]=='G') { n++;M++;c[2][3]++;m[2]++;}
						}
						else if(s[n]=='A')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[3][0]++;m[3]++;}
							else if(s[n]=='C') { n++;M++;c[3][1]++;m[3]++;}
							else if(s[n]=='A'||s[n]=='G') { n++;M++; }
						}
						else if(s[n]=='G')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[4][0]++;m[4]++;}
							else if(s[n]=='C') { n++;M++;c[4][1]++;m[4]++;}
							else if(s[n]=='A') { n++;M++; }
							else if(s[n]=='G') {n++;M++;c[5][0]++;m[5]++;}
						}
					}
					else if(s[n]=='C')
					{
						n++;
						if(s[n]=='T')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[1][2]++;m[1]++;}
							else if(s[n]=='C') { n++;M++;c[1][3]++;m[1]++;}
							else if(s[n]=='A') { n++;M++;c[1][4]++;m[1]++;}
							else if(s[n]=='G') { n++;M++;c[1][5]++;m[1]++;}
						}
						else if(s[n]=='C')
						{
							n++;
                            if(s[n]=='T') { n++;M++;c[6][0]++;m[6]++;}
							else if(s[n]=='C') { n++;M++;c[6][1]++;m[6]++;}
							else if(s[n]=='A') { n++;M++;c[6][2]++;m[6]++;}
							else if(s[n]=='G') { n++;M++;c[6][3]++;m[6]++;}
						}
						else if(s[n]=='A')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[7][0]++;m[7]++;}
							else if(s[n]=='C') { n++;M++;c[7][1]++;m[7]++;}
							else if(s[n]=='A') { n++;M++;c[8][0]++;m[8]++;}
							else if(s[n]=='G') { n++;M++;c[8][1]++;m[8]++;}
						}
						else if(s[n]=='G')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[9][0]++;m[9]++;}
							else if(s[n]=='C') { n++;M++;c[9][1]++;m[9]++;}
							else if(s[n]=='A') { n++;M++;c[9][2]++;m[9]++;}
							else if(s[n]=='G') { n++;M++;c[9][3]++;m[9]++;}
						}
					}
					else if(s[n]=='A')
					{
						n++;
						if(s[n]=='T')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[10][0]++;m[10]++;}
							else if(s[n]=='C') { n++;M++;c[10][1]++;m[10]++;}
							else if(s[n]=='A') { n++;M++;c[10][2]++;m[10]++;}
							else if(s[n]=='G') { n++;M++;c[11][0]++;m[11]++;}
						}
						else if(s[n]=='C')
						{
							n++;
							if(s[n]=='T') {n++;M++;c[12][0]++;m[12]++;}
							else if(s[n]=='C') {n++;M++;c[12][1]++;m[12]++;}
							else if(s[n]=='A') {n++;M++;c[12][2]++;m[12]++;}
							else if(s[n]=='G') {n++;M++;c[12][3]++;m[12]++;}
						}
						else if(s[n]=='A')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[13][0]++;m[13]++;}
							else if(s[n]=='C') { n++;M++;c[13][1]++;m[13]++;}
							else if(s[n]=='A') { n++;M++;c[14][0]++;m[14]++;}
							else if(s[n]=='G') { n++;M++;c[15][0]++;m[14]++;}
						}
						else if(s[n]=='G')
						{
							n++;
							if(s[n]=='T') {n++;M++;c[2][4]++;m[2]++;}
							else if(s[n]=='C') {n++;M++;c[2][5]++;m[2]++;}
							else if(s[n]=='A') { n++;M++;c[9][4]++;m[9]++;}
							else if(s[n]=='G') { n++;M++;c[9][5]++;m[9]++;}
						}
					}
					else if(s[n]=='G')
					{
						n++;
						if(s[n]=='T')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[15][0]++;m[15]++;}
							else if(s[n]=='C') { n++;M++;c[15][1]++;m[15]++;}
							else if(s[n]=='A') { n++;M++;c[15][2]++;m[15]++;}
							else if(s[n]=='G') { n++;M++;c[15][3]++;m[15]++;}
						}
						else if(s[n]=='C')
						{
							n++;
                            if(s[n]=='T') { n++;M++;c[16][0]++;m[16]++;}
							else if(s[n]=='C') { n++;M++;c[16][1]++;m[16]++;}
							else if(s[n]=='A') { n++;M++;c[16][2]++;m[16]++;}
							else if(s[n]=='G') { n++;M++;c[16][3]++;m[16]++;}
						}
						else if(s[n]=='A')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[17][0]++;m[17]++;}
							else if(s[n]=='C') { n++;M++;c[17][1]++;m[17]++;}
							else if(s[n]=='A') { n++;M++;c[18][0]++;m[18]++;}
							else if(s[n]=='G') { n++;M++;c[18][1]++;m[18]++;}
						}
						else if(s[n]=='G')
						{
							n++;
							if(s[n]=='T') { n++;M++;c[19][0]++;m[19]++;}
							else if(s[n]=='C') { n++;M++;c[19][1]++;m[19]++;}
							else if(s[n]=='A') { n++;M++;c[19][2]++;m[19]++;}
							else if(s[n]=='G') { n++;M++;c[19][3]++;m[19]++;}
						}
					}
				}
				for(i=0;i<20;i++)
					for(j=0;j<6;j++)
					{
						if(c[i][j]!=0)
							Sf[i]+=(c[i][j]/m[i])*(log10(c[i][j]/m[i])/log10(2));
					}
					for(i=0;i<20;i++)
						S1-=(m[i]/M)*Sf[i];
					SK[W]=S1;
					for(i=0;i<20;i++)
						for(j=0;j<6;j++)
							C[W][i][j]=c[i][j];
						for(i=0;i<20;i++)
							F[W][i]=m[i];
						N[W]=M;
				s=""; 
				temp=0;
			}
		}
		else
		{
			s+=line;
			temp=1;
		}
	}
	if(temp)
	{
		M=n=0;
		S1=0;
		W++;
		for(i=0;i<20;i++)
			m[i]=Sf[i]=0;
		for(i=0;i<20;i++)
			for(j=0;j<6;j++)
				c[i][j]=0;
		while(s[n])
		{
			if(s[n]=='T')
			{
				n++;
				if(s[n]=='T')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[0][0]++;m[0]++;}
					else if(s[n]=='C') { n++;M++;c[0][1]++;m[0]++;}
					else if(s[n]=='A') { n++;M++;c[1][0]++;m[1]++;}
					else if(s[n]=='G') { n++;M++;c[1][1]++;m[1]++;} 
				}
				else if(s[n]=='C')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[2][0]++;m[2]++;}
					else if(s[n]=='C') { n++;M++;c[2][1]++;m[2]++;}
					else if(s[n]=='A') { n++;M++;c[2][2]++;m[2]++;}
					else if(s[n]=='G') { n++;M++;c[2][3]++;m[2]++;}
				}
				else if(s[n]=='A')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[3][0]++;m[3]++;}
					else if(s[n]=='C') { n++;M++;c[3][1]++;m[3]++;}
					else if(s[n]=='A'||s[n]=='G') { n++;M++; }
				}
				else if(s[n]=='G')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[4][0]++;m[4]++;}
					else if(s[n]=='C') { n++;M++;c[4][1]++;m[4]++;}
					else if(s[n]=='A') { n++;M++; }
					else if(s[n]=='G') {n++;M++;c[5][0]++;m[5]++;}
				}
			}
			else if(s[n]=='C')
			{
				n++;
				if(s[n]=='T')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[1][2]++;m[1]++;}
					else if(s[n]=='C') { n++;M++;c[1][3]++;m[1]++;}
					else if(s[n]=='A') { n++;M++;c[1][4]++;m[1]++;}
					else if(s[n]=='G') { n++;M++;c[1][5]++;m[1]++;}
				}
				else if(s[n]=='C')
				{
					n++;
                    if(s[n]=='T') { n++;M++;c[6][0]++;m[6]++;}
					else if(s[n]=='C') { n++;M++;c[6][1]++;m[6]++;}
					else if(s[n]=='A') { n++;M++;c[6][2]++;m[6]++;}
					else if(s[n]=='G') { n++;M++;c[6][3]++;m[6]++;}
				}
				else if(s[n]=='A')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[7][0]++;m[7]++;}
					else if(s[n]=='C') { n++;M++;c[7][1]++;m[7]++;}
					else if(s[n]=='A') { n++;M++;c[8][0]++;m[8]++;}
					else if(s[n]=='G') { n++;M++;c[8][1]++;m[8]++;}
				}
				else if(s[n]=='G')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[9][0]++;m[9]++;}
					else if(s[n]=='C') { n++;M++;c[9][1]++;m[9]++;}
					else if(s[n]=='A') { n++;M++;c[9][2]++;m[9]++;}
					else if(s[n]=='G') { n++;M++;c[9][3]++;m[9]++;}
				}
			}
			else if(s[n]=='A')
			{
				n++;
				if(s[n]=='T')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[10][0]++;m[10]++;}
					else if(s[n]=='C') { n++;M++;c[10][1]++;m[10]++;}
					else if(s[n]=='A') { n++;M++;c[10][2]++;m[10]++;}
					else if(s[n]=='G') { n++;M++;c[11][0]++;m[11]++;}
				}
				else if(s[n]=='C')
				{
					n++;
					if(s[n]=='T') {n++;M++;c[12][0]++;m[12]++;}
					else if(s[n]=='C') {n++;M++;c[12][1]++;m[12]++;}
					else if(s[n]=='A') {n++;M++;c[12][2]++;m[12]++;}
					else if(s[n]=='G') {n++;M++;c[12][3]++;m[12]++;}
				}
				else if(s[n]=='A')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[13][0]++;m[13]++;}
					else if(s[n]=='C') { n++;M++;c[13][1]++;m[13]++;}
					else if(s[n]=='A') { n++;M++;c[14][0]++;m[14]++;}
					else if(s[n]=='G') { n++;M++;c[15][0]++;m[14]++;}
				}
				else if(s[n]=='G')
				{
					n++;
					if(s[n]=='T') {n++;M++;c[2][4]++;m[2]++;}
					else if(s[n]=='C') {n++;M++;c[2][5]++;m[2]++;}
					else if(s[n]=='A') { n++;M++;c[9][4]++;m[9]++;}
					else if(s[n]=='G') { n++;M++;c[9][5]++;m[9]++;}
				}
			}
			else if(s[n]=='G')
			{
				n++;
				if(s[n]=='T')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[15][0]++;m[15]++;}
					else if(s[n]=='C') { n++;M++;c[15][1]++;m[15]++;}
					else if(s[n]=='A') { n++;M++;c[15][2]++;m[15]++;}
					else if(s[n]=='G') { n++;M++;c[15][3]++;m[15]++;}
				}
				else if(s[n]=='C')
				{
					n++;
                    if(s[n]=='T') { n++;M++;c[16][0]++;m[16]++;}
					else if(s[n]=='C') { n++;M++;c[16][1]++;m[16]++;}
					else if(s[n]=='A') { n++;M++;c[16][2]++;m[16]++;}
					else if(s[n]=='G') { n++;M++;c[16][3]++;m[16]++;}
				}
				else if(s[n]=='A')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[17][0]++;m[17]++;}
					else if(s[n]=='C') { n++;M++;c[17][1]++;m[17]++;}
					else if(s[n]=='A') { n++;M++;c[18][0]++;m[18]++;}
					else if(s[n]=='G') { n++;M++;c[18][1]++;m[18]++;}
				}
				else if(s[n]=='G')
				{
					n++;
					if(s[n]=='T') { n++;M++;c[19][0]++;m[19]++;}
					else if(s[n]=='C') { n++;M++;c[19][1]++;m[19]++;}
					else if(s[n]=='A') { n++;M++;c[19][2]++;m[19]++;}
					else if(s[n]=='G') { n++;M++;c[19][3]++;m[19]++;}
				}
			}
		}
		for(i=0;i<20;i++)
			for(j=0;j<6;j++)
			{
				if(c[i][j]!=0)
					Sf[i]+=(c[i][j]/m[i])*(log10(c[i][j]/m[i])/log10(2));
			}
			for(i=0;i<20;i++)
				S1-=(m[i]/M)*Sf[i];
			SK[W]=S1;
			for(i=0;i<20;i++)
				for(j=0;j<6;j++)
					C[W][i][j]=c[i][j];
				for(i=0;i<20;i++)
					F[W][i]=m[i];
				N[W]=M;
	}
	infile.close();
	// cout<<W<<endl;
	for(k=1;k<=W;k++)
		for(i=0;i<20;i++)
			for(j=0;j<6;j++)
				Call[i][j]+=C[k][i][j];
	for(k=1;k<=W;k++)
		for(i=0;i<20;i++)
			Fall[i]+=F[k][i];
	for(k=1;k<=W;k++)
		Nall+=N[k];
	for(k=1;k<=W;k++)
	{
		for(i=0;i<20;i++)
			Sn[i]=SF[i]=0.0;
		S=Sn1=0;
		for(i=0;i<20;i++)
			for(j=0;j<6;j++)
			{
				if(Call[i][j]!=0)//
					Sn[i]+=((Call[i][j]-C[k][i][j])/(Fall[i]-F[k][i]))*(log10((Call[i][j]-C[k][i][j])/(Fall[i]-F[k][i]))/log10(2));
			}
		for(i=0;i<20;i++)
			for(j=0;j<6;j++)
			{
				if(Call[i][j]!=0)//
					SF[i]+=(Call[i][j]/Fall[i])*(log10(Call[i][j]/Fall[i])/log10(2));
			}
		for(i=0;i<20;i++)
			Sn1-=(Fall[i]-F[k][i])/(Nall-N[k])*Sn[i];
		for(i=0;i<20;i++)
			S-=(Fall[i]/Nall)*SF[i];
		JS=S-N[k]/Nall*SK[k]-(Nall-N[k])/Nall*Sn1;
	    x=Nall*log(2)*JS;
	
		z=gamm2(31.5,x,e1,e0);
		outfile<<z<<endl;
	}
	outfile.close();
	return 0;
}
