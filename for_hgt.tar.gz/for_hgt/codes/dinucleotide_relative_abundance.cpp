#include<iostream>
#include<fstream>
#include<string>
#include<math.h>

using namespace std;
float Wp[100000][16];

int main(int argc, char * argv[])
{
	string name(argv[1]);
	name = name.substr(0, name.find_last_of("."));

	ifstream infile(argv[1],ios::in);
	ofstream outfile((name+"_dinucleotide.txt").c_str(),ios::out);
	string p,s,line;
	float F[16],f[4],M2[16],M1[4];
	float Pg[16],PG[16];	
	int i,j,temp,W;
	float n,N,N1,q,Q;
	N=N1=q=0.0;
	temp=W=0;
	for(i=0;i<16;i++)
		M2[i]=0.0;
	for(i=0;i<4;i++)
		M1[i]=0.0;
	while(getline(infile,line))
	{ 
		if(line[0]=='>')
		{
			if(temp)
			{
				W++;
				n=0;
				for(i=0;i<16;i++)
					F[i]=0.0;
				for(i=0;i<4;i++)
					f[i]=0.0;
				while(s[n])
				{
					if(s[n]=='A')
					{
						n++;f[0]++;
						if(s[n]=='A')       {f[0]++;F[0]++;}
						else if(s[n]=='T')  {f[1]++;F[1]++;}
						else if(s[n]=='C')  {f[2]++;F[2]++;}
						else if(s[n]=='G')  {f[3]++;F[3]++;}
					}
					else if(s[n]=='T')
					{
						n++;f[1]++;
						if(s[n]=='A')       {f[0]++;F[4]++;}
					    else if(s[n]=='T')  {f[1]++;F[5]++;}
					    else if(s[n]=='C')  {f[2]++;F[6]++;}
						else if(s[n]=='G')  {f[3]++;F[7]++;}
					}
					else if(s[n]=='C')
					{
						n++;f[2]++;
						if(s[n]=='A')       {f[0]++;F[8]++;}
						else if(s[n]=='T')  {f[1]++;F[9]++;}
						else if(s[n]=='C')  {f[2]++;F[10]++;}
						else if(s[n]=='G')  {f[3]++;F[11]++;}
					}
					else
					{
						n++;f[3]++;
						if(s[n]=='A')       {f[0]++;F[12]++;}
						else if(s[n]=='T')  {f[1]++;F[13]++;}
						else if(s[n]=='C')  {f[2]++;F[14]++;}							
						else if(s[n]=='G')  {f[3]++;F[15]++;}
					}
					n++;
				}
				for(i=0;i<16;i++)
					Pg[i]=(F[i]/(n/2))/((f[i/4]/n)*(f[i%4]/n));
				for(i=0;i<16;i++)
					Wp[W-1][i]=Pg[i];
				for(i=0;i<16;i++)
				{
					N+=F[i];
					M2[i]+=F[i];
				}
				for(i=0;i<4;i++)
				{
					N1+=f[i];
					M1[i]+=f[i];
				}
				s="";
				temp=0;
			}
		}
		else
		{
			s+=line;
			temp=1;
		}
	}
	infile.close();
	if(temp)
	{
		W++;
		n=0;
		for(i=0;i<16;i++)
			F[i]=0.0;
		for(i=0;i<4;i++)
			f[i]=0.0;
		while(s[n])
		{
			if(s[n]=='A')
			{
				n++;f[0]++;
				if(s[n]=='A')       {f[0]++;F[0]++;}
				else if(s[n]=='T')  {f[1]++;F[1]++;}
				else if(s[n]=='C')  {f[2]++;F[2]++;}
				else if(s[n]=='G')  {f[3]++;F[3]++;}
			}
			else if(s[n]=='T')
			{
				n++;f[1]++;
				if(s[n]=='A')       {f[0]++;F[4]++;}
			    else if(s[n]=='T')  {f[1]++;F[5]++;}
			    else if(s[n]=='C')  {f[2]++;F[6]++;}
				else if(s[n]=='G')  {f[3]++;F[7]++;}
			}
			else if(s[n]=='C')
			{
				n++;f[2]++;
				if(s[n]=='A')       {f[0]++;F[8]++;}
				else if(s[n]=='T')  {f[1]++;F[9]++;}
				else if(s[n]=='C')  {f[2]++;F[10]++;}
				else if(s[n]=='G')  {f[3]++;F[11]++;}
			}
			else
			{
				n++;f[3]++;
				if(s[n]=='A')       {f[0]++;F[12]++;}
				else if(s[n]=='T')  {f[1]++;F[13]++;}
				else if(s[n]=='C')  {f[2]++;F[14]++;}							
				else if(s[n]=='G')  {f[3]++;F[15]++;}
			}
			n++;
		}
		for(i=0;i<16;i++)
			Pg[i]=(F[i]/(n/2))/((f[i/4]/n)*(f[i%4]/n));
		for(i=0;i<16;i++)
			Wp[W-1][i]=Pg[i];
		for(i=0;i<16;i++)
		{
			N+=F[i];
			M2[i]+=F[i];
		}
		for(i=0;i<4;i++)
		{
			N1+=f[i];
			M1[i]+=f[i];
		}
	}
	for(i=0;i<16;i++)
		PG[i]=(M2[i]/N)/((M1[i/4]/N1)*(M1[i%4]/N1));
	// cout<<W<<endl;
	for(j=0;j<W;j++)
	{
		for(i=0;i<16;i++)
			q+=fabs(Wp[j][i]-PG[i]);
		Q=(1.0/16.0)*q;
		outfile<<Q<<endl;
		q=0;
	}
	outfile.close();
	return 0;
}
