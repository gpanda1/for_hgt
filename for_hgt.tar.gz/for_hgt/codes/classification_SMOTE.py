import numpy as np
from sklearn import preprocessing, model_selection
from sklearn.svm import SVC
from imblearn.over_sampling import SMOTE
import sys

data = np.loadtxt("Escherichia_coli_K12.features")
n_row, n_column = data.shape
X_train = data[:, :n_column-1]
y_train = data[:, n_column-1]

min_max_scaler = preprocessing.MinMaxScaler()
X_train = min_max_scaler.fit_transform(X_train)

indices = np.array(range(X_train.shape[0]))
np.random.shuffle(indices)
X_train, y_train = X_train[indices, :], y_train[indices]

Recalls, Mean_errors = [], []
for i in range(3):
	kf = model_selection.StratifiedKFold(n_splits=5, shuffle=True)
	Recalls_, Mean_errors_ = [], []
	for train_indices, test_indices in kf.split(X_train, y_train):
		train_X, train_y = X_train[train_indices, :], y_train[train_indices]
		test_X, test_y = X_train[test_indices, :], y_train[test_indices]

		sm = SMOTE()
		train_X_res, train_y_res = sm.fit_sample(train_X, train_y)

		clf = SVC(probability=True) #need to adjust the parameters of C and gamma
		clf.fit(train_X_res, train_y_res)

		test_probs = clf.predict_proba(test_X)[:, 1]

		Recall, Mean_error = [], []
		for p in np.arange(0, 1, 0.001):
			TP, TN, FP, FN = 0, 0, 0, 0
			for ind in range(test_probs.shape[0]):
				pred = 1 if test_probs[ind] >= p else 0
				if pred == 1 and test_y[ind] == 1:
					TP += 1
				elif pred == 1 and test_y[ind] == 0:
					FP += 1
				elif pred == 0 and test_y[ind] == 0:
					TN += 1
				else:
					FN += 1

			R = 1.0*TP/(TP+FN)
			M = (1.0*FN/(TP+FN)+1.0*FP/(TN+FP))/2

			Recall.append(R)
			Mean_error.append(M)

		Recalls.append(Recall[Mean_error.index(min(Mean_error))])
		Mean_errors.append(min(Mean_error))

print np.mean(np.array(Recalls)), np.mean(np.array(Mean_errors))
