
#REQUIREMENT
(1) gcc and g++ compilers;
(2) python and scikit-learn packages;

#USAGE

(1) Please change directory to the "./codes/" sub-folder, compile *.cpp files using command "g++ *.cpp -o *";

(2) Take Escherichia coli K12 genome as an example, the genome location and hgt location can be extracted respectively by running "./retrieve ../data/Escherichia_coli_K12.txt Escherichia_coli_K12.hgt", or "retrieve.py ../data/Escherichia_coli_K12.txt Escherichia_coli_K12.hgt", it depends on the format of genome file;

(3) The feature file can be extracted by running "./integrate_features ../data/Escherichia_coli_K12.txt";

(4) The "classification.py" and "classification_SMOTE.py" files can be used to perform cross validation.


#CONTACT
If you have any questiones, please contact Dapeng Xiong(dpxiong@live.com).

Thanks!
