#include<iostream>
#include<fstream>
#include<string>
#include<math.h>

using namespace std;

int main(int argc, char * argv[])
{
	string name(argv[1]);
	name = name.substr(0, name.find_last_of("."));

	ifstream infile((name+".genome_location").c_str(),ios::in);
	ifstream infile1((name+".hgt_location").c_str(),ios::in);
	ofstream outfile((name+".hgt_label").c_str(),ios::out);
	string line,line1,str1,str2;
	int k,t,i,j,n1,n2,m1[10000],m2[10000],m3[10000],m4[10000];
	int countP=0;
	n1=n2=i=j=1;
	for(k=1;k<=10000;k++)
		m3[k]=0;
	while(getline(infile,line))
	{
		str1=line.substr(0,line.find_first_of("	"));
		sscanf(str1.c_str(),"%d",&m1[n1]);
		line=line.substr(line.find("	")+1);
		sscanf(line.c_str(),"%d",&m2[n1]);
		n1++;		
	}
	while(getline(infile1,line1))
	{
		str2=line1.substr(0,line1.find_first_of("	"));
		sscanf(str2.c_str(),"%d",&m3[n2]);
		line1=line1.substr(line1.find("	")+1);
		sscanf(line1.c_str(),"%d",&m4[n2]);
		n2++;
	}
	while(m3[j]!=0)
	{
		if((m1[i]==m3[j])&&(m2[i]==m4[j]))
		{
			outfile<<"1"<<endl;
			i++;j++;
			countP++;
		}
		else if(m1[i]>m4[j])   j++;
		else if(m2[i]<m3[j])
		{
			outfile<<"0"<<endl;
			i++;
		}
		else if(m1[i]>=m3[j]&&m2[i]<=m4[j])
		{
			outfile<<"1"<<endl;
			i++;j++;
			countP++;
		}
		else if(m1[i]>m3[j]&&m1[i]<m4[j]&&m2[i]>m4[j])   j++;
		else 
		{
			outfile<<"0"<<endl;
			i++;
		}
	}
	for(t=i;t<n1;t++)
		outfile<<"0"<<endl;

	infile.close();
	infile1.close();
	outfile.close();
	return 0;
}