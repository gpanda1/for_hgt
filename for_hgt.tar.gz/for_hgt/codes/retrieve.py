import sys

infile = open(sys.argv[1], 'r')
infile1 = open(sys.argv[2], 'r')
name = sys.argv[1][:sys.argv[1].rindex('.')]
outfile = open(name+'.genome_location', 'w')
outfile1 = open(name+'.hgt_location', 'w')

for line in infile:
	if line[0] == '>':
		s = []
		line_list = line[line.index('|:')+2:line.index(' ')].split(',')
		for ele in line_list:
			s1, s2 = ele.split('-')
			if s1[0] != 'c':
				s.append(s1)
				s.append(s2)
			else:
				s.append(s2)
				s.append(s1[1:])

		outfile.write(s[0]+'	'+s[1]+'\n')
infile.close()
outfile.close()

for line in infile1.readlines()[1:]:
	line_list = line.split()
	outfile1.write(line_list[2]+'	'+line_list[3]+'\n')
infile1.close()
outfile1.close()
