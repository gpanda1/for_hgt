#include <iostream>
#include <fstream>
#include <string>           

using namespace std;

int main(int argc, char * argv[])
{
	ifstream infile(argv[1],ios::in);
	ifstream infile1(argv[2],ios::in);
	string name(argv[1]);
	name = name.substr(0, name.find_last_of("."));
	ofstream outfile((name+".genome_location").c_str(),ios::out);
	ofstream outfile1((name+".hgt_location").c_str(),ios::out);
	string line,line1,str1,str2,str3,str4;
	while(getline(infile,line))
	{
		if(line[0] == '>')
		{
			line = line.substr(line.find("[location="));
			if(line[line.length()-2] == ')'&&line[line.length()-3]!=')')
			{
				line = line.substr(line.find("(")+1);
				str1=line.substr(0,line.find("."));
				line = line.substr(line.find(".")+2);
				str2 = line.substr(0,line.find_first_of(")"));
			}
            else if(line[line.length()-3]==')')
			{
				line=line.substr (line.find_last_of ("(")+1);
				str1=line.substr(0,line.find("."));
				line =line.substr(line.find_last_of (".")+1);
				str2=line.substr(0,line.find_first_of(")"));
			}
			else
			{
			    line = line.substr(line.find("=")+1);
		     	str1 = line.substr(0,line.find("."));
		    	line = line.substr(line.find(".")+2);
		    	str2 = line.substr(0,line.find_first_of(")]"));
			}
			outfile << str1 << "	" << str2 << endl;
		}
	}
	getline(infile1, line1);
	while(getline(infile1,line1))
	{
		line1 = line1.substr(line1.find("	")+1);
		line1 = line1.substr(line1.find("	")+1);
		str3 = line1.substr(0,line1.find("	"));
		line1 = line1.substr(line1.find("	")+1);
		str4 = line1.substr(0,line1.find("	"));
		outfile1 << str3 <<"	" << str4 << endl;
	}
	infile.close();
	infile1.close();
	outfile.close();
	outfile1.close();
	return 0;
}