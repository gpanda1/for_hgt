#include<iostream>
#include <stdlib.h>
#include<fstream>
#include<string>
#include<math.h>

using namespace std;

int main(int argc, char * argv[])
{
	string p1(argv[1]);
	system(("./align "+p1).c_str());
	system(("./codon_usage_bias "+p1).c_str());
	system(("./dinucleotide_relative_abundance "+p1).c_str());
	system(("./GC1-GC3 "+p1).c_str());
	system(("./x2_codon_usage_bias "+p1).c_str());
	system(("./x2_dinucleotide_relative_abundance "+p1).c_str());
	system(("./JS-N "+p1).c_str());
	system(("./JS-DN "+p1).c_str());
	system(("./JS-CB "+p1).c_str());
	system(("./k_1 "+p1).c_str());
	system(("./k_2 "+p1).c_str());
	system(("./k_3 "+p1).c_str());
	system(("./k_4 "+p1).c_str());
	system(("./k_5 "+p1).c_str());
	system(("./k_6 "+p1).c_str());
	system(("./k_7 "+p1).c_str());
	string name(argv[1]);
	name = name.substr(0, name.find_last_of("."));
	string line,line1,line2,line3,line4,line5,line6,line7,line8,line9,line10,line11,line12,line13,line14,line15,line16,line17;
	ifstream infile((name+".hgt_label").c_str(),ios::in);
	ifstream infile1((name+"_codon_usage_bias.txt").c_str(),ios::in);
	ifstream infile2((name+"_dinucleotide.txt").c_str(),ios::in);
	ifstream infile3((name+"_GC1_GC3.txt").c_str(),ios::in);
	ifstream infile4((name+"_x2_codon_usage_bias.txt").c_str(),ios::in);
	ifstream infile5((name+"_x2_dinucleotide.txt").c_str(),ios::in);
	ifstream infile6((name+"_JS_N.txt").c_str(),ios::in);
	ifstream infile7((name+"_JS_DN.txt").c_str(),ios::in);
	ifstream infile8((name+"_JS_CB.txt").c_str(),ios::in);
	ifstream infile9((name+"_k_1.txt").c_str(),ios::in);
	ifstream infile10((name+"_k_2.txt").c_str(),ios::in);
	ifstream infile11((name+"_k_3.txt").c_str(),ios::in);
	ifstream infile12((name+"_k_4.txt").c_str(),ios::in);
	ifstream infile13((name+"_k_5.txt").c_str(),ios::in);
	ifstream infile14((name+"_k_6.txt").c_str(),ios::in);
	ifstream infile15((name+"_k_7.txt").c_str(),ios::in);
	ofstream outfile((name+".features").c_str(),ios::out);
	while(getline(infile,line))
	{
		getline(infile1,line1);
		getline(infile2,line2);
		getline(infile3,line3);
		getline(infile4,line4);
		getline(infile5,line5);
		getline(infile6,line6);
		getline(infile7,line7);
		getline(infile8,line8);
		getline(infile9,line9);
		getline(infile10,line10);
		getline(infile11,line11);
		getline(infile12,line12);
		getline(infile13,line13);
		getline(infile14,line14);
		getline(infile15,line15);
		if(line[0]=='1')
			outfile<<line1<<" "<<line2<<" "<<line3<<" "<<line4<<" "<<line5<<" "<<line6<<" "
		    	<<line7<<" "<<line8<<" "<<line9<<" "<<line10<<" "<<line11<<" "<<line12<<" "<<line13<<" "
				<<line14<<" "<<line15<<" 1"<<endl;
		else if(line[0]=='0')
		    outfile<<line1<<" "<<line2<<" "<<line3<<" "<<line4<<" "<<line5<<" "<<line6<<" "
		    	<<line7<<" "<<line8<<" "<<line9<<" "<<line10<<" "<<line11<<" "<<line12<<" "<<line13<<" "
				<<line14<<" "<<line15<<" 0"<<endl;
	}
	infile.close();
	infile1.close();
	infile2.close();
	infile3.close();
	infile4.close();
	infile5.close();
	infile6.close();
	infile7.close();
	infile8.close();
	infile9.close();
	infile10.close();
	infile11.close();
	infile12.close();
	infile13.close();
	infile14.close();
	infile15.close();
	outfile.close();
	return 0;
}
