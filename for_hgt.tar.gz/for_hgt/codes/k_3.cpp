#include<iostream>
#include<fstream>
#include<string>
#include<math.h>

using namespace std;
float P[10000][64];

int main(int argc, char * argv[])
{
	string name(argv[1]);
	name = name.substr(0, name.find_last_of("."));

	ifstream infile(argv[1],ios::in);
	ofstream outfile((name+"_k_3.txt").c_str(),ios::out);
	string s,line;
	float f,Nn[64],Pf[64],PG[64];
	int i,k,temp,n,W,m;
	temp=W=0;
	for(i=0;i<64;i++)
		Pf[i]=0.0;
	while(getline(infile,line))
	{
		if(line[0]=='>')
		{
			if(temp)
			{
				n=3;
				m=0;
				W++;
				for(i=0;i<64;i++)
					Nn[i]=0.0;
				for(i=0;i<3;i++)
				{
					if(s[i]=='A') m+=0*pow(4,2-i);
					else if(s[i]=='T') m+=1*pow(4,2-i);
					else if(s[i]=='C') m+=2*pow(4,2-i);
					else if(s[i]=='G') m+=3*pow(4,2-i);
				}
				Nn[m]++;
				while(s[n])
				{
					if(s[n]=='A')
					{
						m=(m%16)*4+0;
						Nn[m]++;
					}
					else if(s[n]=='T')
					{
						m=(m%16)*4+1;
						Nn[m]++;
					}
					else if(s[n]=='C')
					{
						m=(m%16)*4+2;
						Nn[m]++;
					}
					else if(s[n]=='G')
					{
						m=(m%16)*4+3;
						Nn[m]++;
					}
					n++;
				}
				for(i=0;i<64;i++)
				{
					P[W][i]=Nn[i]/(n-2);
					Pf[i]+=P[W][i];
				}
			    s="";
				temp=0;
			}
		}
		else
		{
			s+=line;
			temp=1;
		}
	}
	if(temp)
	{
		n=3;
		m=0;
		W++;
		for(i=0;i<64;i++)
			Nn[i]=0.0;
		for(i=0;i<3;i++)
		{
			if(s[i]=='A') m+=0*pow(4,2-i);
			else if(s[i]=='T') m+=1*pow(4,2-i);
			else if(s[i]=='C') m+=2*pow(4,2-i);
			else if(s[i]=='G') m+=3*pow(4,2-i);
		}
		Nn[m]++;
		while(s[n])
		{
			if(s[n]=='A')
			{
				m=(m%16)*4+0;
				Nn[m]++;
			}
			else if(s[n]=='T')
			{
				m=(m%16)*4+1;
				Nn[m]++;
			}
			else if(s[n]=='C')
			{
				m=(m%16)*4+2;
				Nn[m]++;
			}
			else if(s[n]=='G')
			{
				m=(m%16)*4+3;
				Nn[m]++;
			}
			n++;
		}
		for(i=0;i<64;i++)
		{
			P[W][i]=Nn[i]/(n-2);
			Pf[i]+=P[W][i];
		}
	}
	// cout<<W<<endl;
	infile.close();
	for(i=0;i<64;i++)
		PG[i]=Pf[i]/W;
	for(k=1;k<=W;k++)
	{
		f=0.0;
		for(i=0;i<64;i++)
			f+=fabs(P[k][i]-PG[i])/64;
		outfile<<f<<endl;
	}
	outfile.close();
	return 0;
}
