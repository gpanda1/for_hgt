#include<iostream>
#include<fstream>
#include<string>
#include<math.h>

using namespace std;

double gammln(double x);

float JS[10000][10000];
double gamm2(double a,double x,double e1,double e0);
double gammln(double x);

#define NMAX 100

double gammln(double x)
{
  int i;
  double t,s;
  static double c[6] = {76.18009172947148,
            -86.50532032941677,24.01409824083091,
            -1.231739572450155,0.1208650973866179e-2,
            -0.5395239384953e-5};
  if(x<0)
    return(0.0);
  s = 1.000000000190015;
  for(i=0; i<6; i++)
    s = s+c[i]/(x+i);
  t = x+4.5;
  t = t-(x-0.5)*log(t);
  t = log(2.5066282746310005*s)-t;
  return(t);
}

double gamm2(double a,double x,double e1,double e0)
{
  int n;
  double t,del,gln;
  double an,bn,c,d;
  if((x<0.0)||(a<=0))
    return(0.0);
  if(x<e0)
    return(0.0);
  gln = gammln(a);
  if(x<(a+1.0))
  {
    del = 1.0/a;
    t = 1.0/a;
    for(n=1; n<NMAX; n++)
    {
      del = del*x/(a+n);
      t = t+del;
      if(fabs(del)<fabs(t)*e1)
      {
        t = t*exp(-x+a*log(x)-gln);
        return(t);
      }
    }
    return(0.0);
  }
  else
  {
    bn = x+1.0-a;
    c = 1.0/e0;
    d = 1.0/bn;
    t = d;
    for(n=1; n<NMAX; n++)
    {
      an = n*(a-n);
      bn = bn+2.0;
      d = an*d+bn;
      c = bn+an/c;
      if(fabs(d) < e0)
        d = e0;
      if(fabs(c) < e0)
        c = e0;
      d = 1.0/d;
      del = d*c;
      t = t*del;
      if(fabs(del-1.0)<e1)
      {
        t=exp(-x+a*log(x)-gln)*t;
        t = 1.0-t;
        return(t);
      }
    }
    return(0.0);
  }
}



int main(int argc, char * argv[])
{
	string name(argv[1]);
	name = name.substr(0, name.find_last_of("."));

	ifstream infile(argv[1],ios::in);
	ofstream outfile((name+"_JS_N.txt").c_str(),ios::out);
	string p,s,line;
	float f[4],S[10000],N[10000],F[10000][4],Fall[4],JS,S1,SF,Nall,Sn;
	int i,k,temp,n,W;
	float Pr;
	double x,y,z;
    double e1=1.0e-7,e0=1.0e-30; 
	W=temp=0;
	Nall=0;
	for(i=0;i<4;i++)
		Fall[i]=0.0;
	while(getline(infile,line))
	{
		if(line[0]=='>')
		{
			if(temp)
			{
				n=0;
				S1=0.0;
				W++;
				for(i=0;i<4;i++)
					f[i]=0;
				while(s[n])
				{
					if(s[n]=='A')
						f[0]++;
					else if(s[n]=='T')
						f[1]++;
					else if(s[n]=='C')
						f[2]++;
					else f[3]++;
					n++;
				}
				for(i=0;i<4;i++)
					S1-=(f[i]/n)*(log(f[i]/n)/log(2));
				S[W]=S1;
				for(i=0;i<4;i++)
					F[W][i]=f[i];
				N[W]=n;
			    s="";
				temp=0;
			}
		}
		else
		{
			s+=line;
			temp=1;
		}
	}
	if(temp)
	{
		n=0;
		S1=0.0;
		W++;
		for(i=0;i<4;i++)
			f[i]=0;
		while(s[n])
		{
			if(s[n]=='A')
				f[0]++;
			else if(s[n]=='T')
				f[1]++;
			else if(s[n]=='C')
				f[2]++;
			else f[3]++;
			n++;
		}
		for(i=0;i<4;i++)
			S1-=(f[i]/n)*(log(f[i]/n)/log(2));
		S[W]=S1;
		for(i=0;i<4;i++)
			F[W][i]=f[i];
		N[W]=n;
	}
	infile.close();
	// cout<<W<<endl;
	for(i=0;i<4;i++)
		for(k=1;k<=W;k++)
			Fall[i]+=F[k][i];
	for(k=1;k<=W;k++)
		Nall+=N[k];
	for(k=1;k<=W;k++)
	{
		SF=Sn=0.0;
		for(i=0;i<4;i++)
			Sn-=((Fall[i]-F[k][i])/(Nall-N[k]))*(log((Fall[i]-F[k][i])/(Nall-N[k]))/log(2));
		for(i=0;i<4;i++)
			SF-=(Fall[i]/Nall)*(log(Fall[i]/Nall)/log(2));
		JS=SF-(N[k]/Nall)*S[k]-((Nall-N[k])/Nall)*Sn;
	
		x=Nall*log(2)*JS;
		y = gammln(1.5);
		y = exp(y);
		z=gamm2(1.5,x,e1,e0);
		Pr=1-z/y;
		outfile<<Pr<<endl;
	}
	outfile.close();
	return 0;
}
